package com.example.datlichcattoc.Interface;

public interface ICartItemDeleteListener {
    void onCartItemDeleteSuccess();
}
