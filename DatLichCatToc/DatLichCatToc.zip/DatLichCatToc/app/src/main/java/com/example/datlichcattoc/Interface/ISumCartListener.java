package com.example.datlichcattoc.Interface;

public interface ISumCartListener {
    void onSumCartSuccess(Long value);
}
