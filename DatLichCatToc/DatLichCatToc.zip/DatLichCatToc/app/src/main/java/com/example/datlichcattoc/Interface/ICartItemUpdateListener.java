package com.example.datlichcattoc.Interface;

public interface ICartItemUpdateListener {
    void onCartItemUpdateSuccess();
}
