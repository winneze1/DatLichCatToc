package com.example.datlichcattoc.Interface;

public interface IBookingInformationChangeListener {
    void onBookingInformationChange();
}
