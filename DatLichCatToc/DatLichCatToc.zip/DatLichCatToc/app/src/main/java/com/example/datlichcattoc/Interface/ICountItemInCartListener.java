package com.example.datlichcattoc.Interface;

public interface ICountItemInCartListener {
    void onCartItemCountSuccess(int count);
}
