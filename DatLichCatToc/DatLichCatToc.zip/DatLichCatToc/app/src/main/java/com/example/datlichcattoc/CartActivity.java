package com.example.datlichcattoc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.datlichcattoc.Adapter.MyCartAdapter;
import com.example.datlichcattoc.Database.CartDatabase;
import com.example.datlichcattoc.Database.CartItem;
import com.example.datlichcattoc.Database.DatabaseUtils;
import com.example.datlichcattoc.Interface.ICartItemDeleteListener;
import com.example.datlichcattoc.Interface.ICartItemLoadListener;
import com.example.datlichcattoc.Interface.ICartItemUpdateListener;
import com.example.datlichcattoc.Interface.ISumCartListener;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class CartActivity extends AppCompatActivity implements ICartItemLoadListener, ICartItemUpdateListener, ISumCartListener, ICartItemDeleteListener {

    @BindView(R.id.recycler_cart)
    RecyclerView recycler_cart;
    @BindView(R.id.txt_total_price)
    TextView txt_total_price;
    @BindView(R.id.btn_clear_cart)
    Button btn_clear_cart;

    @OnClick(R.id.btn_clear_cart)
    void clearCart(){
        DatabaseUtils.clearCart(cartDatabase);

        //cập nhật adapter
        DatabaseUtils.getAllCart(cartDatabase, this);
        DatabaseUtils.sumCart(cartDatabase, this);
    }

    CartDatabase cartDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        ButterKnife.bind(CartActivity.this);

        cartDatabase = CartDatabase.getInstance(this);

        DatabaseUtils.getAllCart(cartDatabase, this);
        DatabaseUtils.sumCart(cartDatabase, this);

        //View
        recycler_cart.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recycler_cart.setLayoutManager(linearLayoutManager);
        recycler_cart.addItemDecoration(new DividerItemDecoration(this, linearLayoutManager.getOrientation()));
    }

    @Override
    public void onGetAllItemFromCartSuccess(List<CartItem> cartItemList) {
        //Sau khi lay het item cart trong db
        //Hien thi bang Recycler View
        MyCartAdapter adapter = new MyCartAdapter(this, cartItemList, this, this);
        recycler_cart.setAdapter(adapter);
    }



    @Override
    public void onCartItemUpdateSuccess() {
        DatabaseUtils.sumCart(cartDatabase, this);
    }

    @Override
    public void onSumCartSuccess(Long value) {
        txt_total_price.setText(new StringBuilder("$").append(value));
    }

    @Override
    public void onCartItemDeleteSuccess() {
        DatabaseUtils.getAllCart(cartDatabase, this);
    }
}
