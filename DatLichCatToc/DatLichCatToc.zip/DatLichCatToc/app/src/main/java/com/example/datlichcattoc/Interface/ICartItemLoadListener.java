package com.example.datlichcattoc.Interface;

import com.example.datlichcattoc.Database.CartItem;

import java.util.List;

public interface ICartItemLoadListener {
    void onGetAllItemFromCartSuccess(List<CartItem> cartItemList);
}
