package com.example.appcuathocattoc.Interface;

public interface IOnLoadCountSalon {
    void onLoadCountSalonSuccess(int count);

}
