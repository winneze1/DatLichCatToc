package com.example.appcuathocattoc.Interface;

import com.example.appcuathocattoc.Model.ShoppingItem;

public interface IOnShoppingItemSelected {
    void onShoppingItemSelected(ShoppingItem shoppingItem);
}
