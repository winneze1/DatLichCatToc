package com.example.appcuathocattoc.Interface;

import com.example.appcuathocattoc.Model.Barber;

public interface IGetBarberListener {
    void onGetBarberSuccess(Barber barber);
}
