package com.example.appcuathocattoc.Interface;

public interface INotificationCountListener {
    void onNotificationCountSuccess(int count);
}
