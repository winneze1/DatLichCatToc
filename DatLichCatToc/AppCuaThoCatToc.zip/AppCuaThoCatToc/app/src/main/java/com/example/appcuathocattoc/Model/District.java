package com.example.appcuathocattoc.Model;

public class District {
    private String name;

    public District() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
