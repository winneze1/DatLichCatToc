package com.example.appcuathocattoc.Interface;

public interface IUserLoginRememberListener {
    void onUserLoginSuccess(String user);
}
